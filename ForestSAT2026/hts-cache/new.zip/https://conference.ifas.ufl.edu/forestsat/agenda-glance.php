<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<!-- Core Bootstrap CDN -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<!-- Bootstrap Icons -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<!-- Google Fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
<!-- Custom Bootstrap Overrides -->
<link href="css/custom.css" rel="stylesheet">
<!-- Owl Carousel -->
<link href="css/owlcarousel/owl.carousel.css" rel="stylesheet">
<link href="css/owlcarousel/owl.theme.default.css" rel="stylesheet">
<!-- Font Awesome -->
<script src="https://kit.fontawesome.com/ca76a7feb5.js" crossorigin="anonymous"></script>
<!-- Favicon -->
<link rel="apple-touch-icon" sizes="180x180" href="images/favicon/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="images/favicon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="images/favicon/favicon-16x16.png">
<link rel="manifest" href="images/favicon/site.webmanifest">
	<title>Agenda-at-a-Glance | ForestSAT 2026</title>
  </head>
  <body>
	<header class="d-print-none fixed-top">
      <nav class="navbar navbar-expand-xxl bg-primary py-0">
        <div class="container">
          <a class="navbar-brand pt-1 pb-3" href="index.php">
            <img src="images/navbar-logo.svg" alt="ForestSAT2026 Navbar Logo" width="190px">
          </a>
          <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
            <ul class="navbar-nav me-auto">
              <li class="nav-item mx-1">
                <a class="nav-link text-white fw-semibold text-center" href="index.php">
                  Home
                </a>
              </li>
			  <li class="nav-item dropdown mx-1">
                <a class="nav-link dropdown-toggle text-white fw-semibold text-center" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  About
                </a>
                <ul class="dropdown-menu">
				  <li><a class="dropdown-item" href="executive-organizing-committee.php">Executive Organizing Committee</a></li>
                  <li><a class="dropdown-item" href="benefits-attending.php">Benefits of Attending</a></li>
                  <li><a class="dropdown-item" href="who-should-attend.php">Who Will Attend</a></li>
                </ul>
              </li>
              <li class="nav-item dropdown mx-1">
                <a class="nav-link dropdown-toggle text-white fw-semibold text-center" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  Program
                </a>
                <ul class="dropdown-menu">
									<li><a class="dropdown-item" href="call-pre-conference-workshop-proposals.php">Call for Pre-Conference Workshop Proposals</a></li>
									<li><a class="dropdown-item" href="call-session-proposals.php">Call for Session Proposals</a></li>
									<div role="separator" class="dropdown-divider" style="border-top: solid thin #ccc; margin: 8px 0px;"></div>
									<li><a class="dropdown-item" href="key-dates-deadlines.php">Key Dates &amp; Deadlines</a></li>
									<li><a class="dropdown-item" href="agenda-glance.php">Agenda-at-a-Glance (Single Row)</a></li>
									<li><a class="dropdown-item" href="agenda-glance-horiz.php">Agenda-at-a-Glance (Column View)</a></li>
                  <li><a class="dropdown-item" href="program-presentation-topics.php">Program &amp; Presentation Topics</a></li>
                </ul>
              </li>
              <li class="nav-item dropdown mx-1">
                <a class="nav-link dropdown-toggle text-white fw-semibold text-center" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  Location
                </a>
                <ul class="dropdown-menu">
									<li><a class="dropdown-item" href="meeting-site.php">Meeting Site</a></li>
									<li><a class="dropdown-item" href="entry-into-united-states.php">Entry into the United States</a></li>
                  <li><a class="dropdown-item" href="getting-to-gainesville.php">Getting to Gainesville</a></li>
                  <li><a class="dropdown-item" href="about-gainesville.php">About Gainesville</a></li>
									<li><a class="dropdown-item" href="things-to-do.php">Things to Do</a></li>
									<li><a class="dropdown-item" href="visiting-florida.php">Visiting Florida</a></li>
									<li><a class="dropdown-item" href="electricity-usa.php">Electricity in the USA</a></li>
                </ul>
              </li>
              <li class="nav-item dropdown mx-1">
                <a class="nav-link dropdown-toggle text-white fw-semibold text-center" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  Sponsors
                </a>
                <ul class="dropdown-menu">
                  <li><a class="dropdown-item" href="sponsorship-opportunities.php">Sponsorship Opportunities</a></li>
				  <li><a class="dropdown-item" href="sponsor-display-information.php">Sponsor Display Information</a></li>
                </ul>
              </li>
<!--
              <li class="nav-item dropdown mx-1">
                <a class="nav-link dropdown-toggle text-white fw-semibold text-center" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  Registration
                </a>
                <ul class="dropdown-menu">
                  <li><a class="dropdown-item" href="registration-information.php">Registration Information</a></li>
                </ul>
              </li>
-->
              <li class="nav-item dropdown mx-1">
                <a class="nav-link dropdown-toggle text-white fw-semibold text-center" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  Communications
                </a>
                <ul class="dropdown-menu">
                  <li><a class="dropdown-item" href="publicity-toolbox.php">Publicity Toolbox</a></li>
				  <li><a class="dropdown-item" href="contact-us.php">Contact Us</a></li>
				  <li><a class="dropdown-item" href="https://conference.ifas.ufl.edu/ice.php">In Case of Emergency</a></li>
                </ul>
              </li>
            </ul>
            <ul class="navbar-nav ms-auto mb-4 mb-xxl-0">
              <li class="nav-item mx-1">
                <a class="nav-link text-white fw-semibold text-center" href="https://lp.constantcontactpages.com/sl/AJfGuMn" target="_blank">
                  <i class="far fa-envelope"></i>&nbsp; Subscribe
                </a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
	</header>	<div class="container">
    <div class="row">
      <div class="col-lg-9">
          <article>
            <h1 class="heading fw-bolder mb-2 pb-1">Agenda-at-a-Glance</h1>
						<p class="mb-3 pb-0">Want to view this outline using multiple columns? Try our <a href="agenda-glance-horiz.php" class="fw-bold">"Column View"</a> version.</p>
              <div class="table-responsiive">
                <table class="table table-bordered">
                  <tbody>
                    <tr align="center" valign="middle">
                      <td colspan="2" class="text-white" style="background-color: #324123"><strong>Monday, May 4, 2026</strong></td>
                    </tr>
                    <tr>
                      <td width="20%" align="center" valign="middle" style="background-color: #f5f5f5"><strong>7:00am-7:00pm</strong></td>
                      <td>Pre-Conference Registration Opens at UF Hilton Hotel &amp; Conference Center</td>
                    </tr>
                    <tr>
                      <td align="center" valign="middle" style="background-color: #f5f5f5"><strong>8:30am-5:00pm</strong></td>
                      <td>Pre-Conference Workshops at UF Hilton Hotel &amp; Conference Center</td>
                    </tr>
                    <tr>
                      <td align="center" valign="middle" style="background-color: #f5f5f5"><strong>1:00pm-4:00pm</strong></td>
                      <td>Exhibitors Setup at UF Reitz Union</td>
                    </tr>
                    <tr>
                      <td align="center" valign="middle" style="background-color: #f5f5f5"><strong>5:00pm-7:00pm</strong></td>
                      <td>Ice Breaker Reception at UF Hilton Hotel &amp; Conference Center</td>
                    </tr>
                    <tr align="center" valign="middle">
                      <td colspan="2" class="text-white" style="background-color: #324123"><strong>Tuesday, May 5, 2026</strong></td>
                    </tr>
                    <tr>
                      <td align="center" valign="middle" style="background-color: #f5f5f5"><strong>7:15am-5:00pm</strong></td>
                      <td>Conference Registration Opens at UF Reitz Union</td>
                    </tr>
                    <tr>
                      <td align="center" valign="middle" style="background-color: #f5f5f5"><strong>7:30am-8:30am</strong></td>
                      <td>Early Morning Refreshments in Poster &amp; Sponsor Display Area<br/> 
                      Session 1 Poster Presenters Set up Posters</td>
                    </tr>
                    <tr>
                      <td align="center" valign="middle" style="background-color: #f5f5f5"><strong>8:30am-9:30am</strong></td>
                      <td>Opening Plenary Session 1</td>
                    </tr>
                    <tr>
                      <td align="center" valign="middle" style="background-color: #f5f5f5"><strong>10:00am-11:30am</strong></td>
                      <td>Concurrent Sessions</td>
                    </tr>
                    <tr>
                      <td align="center" valign="middle" style="background-color: #f5f5f5"><strong>11:30am&ndash;1:30pm</strong></td>
                      <td>Lunch &amp; Interactive Group Time</td>
                    </tr>
                    <tr>
                      <td align="center" valign="middle" style="background-color: #f5f5f5"><strong>1:30pm&ndash;3:00pm</strong></td>
                      <td>Concurrent Sessions</td>
                    </tr>
                    <tr>
                      <td align="center" valign="middle" style="background-color: #f5f5f5"><strong>3:30pm-5:00pm</strong></td>
                      <td>Concurrent Sessions</td>
                    </tr>
                    <tr>
                      <td align="center" valign="middle" style="background-color: #f5f5f5"><strong>5:00pm-6:30pm</strong></td>
                      <td>Poster Session 1 and Networking Reception</td>
                    </tr>
                    <tr align="center" valign="middle">
                      <td colspan="2" class="text-white" style="background-color: #324123"><strong>Wednesday, May 6, 2026</strong></td>
                    </tr>
                    <tr>
                      <td align="center" valign="middle" style="background-color: #f5f5f5"><strong>7:15am-5:00pm</strong></td>
                      <td>Conference Registration Opens at Reitz Union</td>
                    </tr>
                    <tr>
                      <td align="center" valign="middle" style="background-color: #f5f5f5"><strong>7:30am-8:30am</strong></td>
                      <td>Early Morning Refreshments in Poster &amp; Sponsor Display Area</td>
                    </tr>
                    <tr>
                      <td align="center" valign="middle" style="background-color: #f5f5f5"><strong>8:30am-9:30am</strong></td>
                      <td>Plenary Session 2</td>
                    </tr>
                    <tr>
                      <td align="center" valign="middle" style="background-color: #f5f5f5"><strong>10:00am-11:30am</strong></td>
                      <td>Concurrent Sessions</td>
                    </tr>
                    <tr>
                      <td align="center" valign="middle" style="background-color: #f5f5f5"><strong>11:30am&ndash;1:30pm</strong></td>
                      <td>Session 1 Poster Presenters Remove Posters<br/> 
                      Lunch &amp; Interactive Group Time<br/> Session 2 Poster Presenters Set Up Posters</td>
                    </tr>
                    <tr>
                      <td align="center" valign="middle" style="background-color: #f5f5f5"><strong>1:30pm&ndash;3:00pm</strong></td>
                      <td>Concurrent Sessions</td>
                    </tr>
                    <tr>
                      <td align="center" valign="middle" style="background-color: #f5f5f5"><strong>3:30pm-5:00pm</strong></td>
                      <td>Concurrent Sessions</td>
                    </tr>
                    <tr>
                      <td align="center" valign="middle" style="background-color: #f5f5f5"><strong>5:00pm-6:30pm</strong></td>
                      <td>Poster Session 2 and Networking Reception</td>
                    </tr>
                    <tr align="center" valign="middle">
                      <td colspan="2" class="text-white" style="background-color: #324123"><strong>Thursday, May 7, 2026</strong></td>
                    </tr>
                    <tr>
                      <td align="center" valign="middle" style="background-color: #f5f5f5"><strong>7:15am-5:00pm</strong></td>
                      <td>Conference Registration Opens at Reitz Union</td>
                    </tr>
                    <tr>
                      <td align="center" valign="middle" style="background-color: #f5f5f5"><strong>7:30am-8:30am</strong></td>
                      <td>Early Morning Refreshments in Poster &amp; Sponsor Display Area</td>
                    </tr>
                    <tr>
                      <td align="center" valign="middle" style="background-color: #f5f5f5"><strong>8:30am-9:30am</strong></td>
                      <td>Plenary Session 3</td>
                    </tr>
                    <tr>
                      <td align="center" valign="middle" style="background-color: #f5f5f5"><strong>10:00am-11:30am</strong></td>
                      <td>Concurrent Sessions</td>
                    </tr>
                    <tr>
                      <td align="center" valign="middle" style="background-color: #f5f5f5"><strong>11:30am&ndash;1:30pm</strong></td>
                      <td>Lunch &amp; Interactive Group Time</td>
                    </tr>
                    <tr>
                      <td align="center" valign="middle" style="background-color: #f5f5f5"><strong>1:30pm&ndash;3:00pm</strong></td>
                      <td>Concurrent Sessions</td>
                    </tr>
                    <tr>
                      <td align="center" valign="middle" style="background-color: #f5f5f5"><strong>3:30pm-5:00pm</strong></td>
                      <td>Closing Plenary Session 4 and Awards Presentations</td>
                    </tr>
                    <tr>
                      <td align="center" valign="middle" style="background-color: #f5f5f5"><strong>3:30pm</strong></td>
                      <td>Exhibitors and Session 2 Poster Presenters Tear Down</td>
                    </tr>
                    <tr>
                      <td align="center" valign="middle" style="background-color: #f5f5f5"><strong>6:00pm-9:00pm</strong></td>
                      <td>Closing Dinner and Conference Finale</td>
                    </tr>
                    <tr align="center" valign="middle">
                      <td colspan="2" class="text-white" style="background-color: #324123"><strong>Friday, May 8, 2026</strong></td>
                    </tr>
                    <tr>
                      <td align="center" valign="middle" style="background-color: #f5f5f5"><strong>8:30am-5:00pm</strong></td>
                      <td>Off-site Educational and Social Field Trips – Details to be Announced</td>
                    </tr>
                  </tbody>
                </table>
						</div>
					</article>
        </div>
      <div class="col-lg-3 d-print-none">
  <div class="sticky-top px-1 mb-3" style="top: 132px">
    <div class="rounded p-3" style="background-color: #F5F5F5">
      <div class="px-2 mt-2">
        <h4 align="center" class="d-inline-block my-1 mb-0 mx-auto w-100 fw-bold">May 4-8, 2026</span></h4>
        <h5 align="center" class="d-inline-block my-1 mx-auto w-100 fw-bold">Gainesville, FL, USA</h5>
      </div>
      <!--
      <div> 
        <a href="https://lp.constantcontactpages.com/su/AQ73Cfn" class="btn btn-primary rounded-lg" style="padding: 9px 0px; width: 100%; margin-top: 10px"><strong>Join Our Mailing List &raquo;</strong></a>
      </div>
      <div> 
        <a href="speaker-presentations.php" class="btn btn-primary rounded-lg" style="padding: 9px; width: 100%; margin-top: 10px"><strong>2022 Presentations</strong></a>
      </div>
      <div> 
        <a href="sponsor-recognition.php" class="btn btn-primary rounded-lg" style="padding: 9px 10px; width: 100%; margin-top: 10px"><strong>2022 Sponsors</strong></a>
      </div>
      <div> 
        <a href="venue-hotel.php" class="btn btn-primary rounded-lg" style="padding: 9px 0px; width: 100%; margin-top: 10px"><strong>Venue &amp; Hotel</strong></a>
      </div>
      <div> 
        <a href="sponsor-recognition.html" class="btn btn-primary rounded-lg" style="padding: 9px 0px; width: 100%; margin-top: 15px"><strong>Sponsorship Recognition »</strong></a>
      </div>
      -->
      <div class="mx-auto px-5"><hr class="my-4"></div>
      <h5 align="center" class="d-inline-block mb-3 mx-auto w-100 fw-bold">Countdown</h5>
      <div id="timer">
        <div id="days" class="rounded-lg mb-2" style="height: 40px; display: flex; align-content: center; justify-content: center; align-items: center; font-size: 18px; background-color: white">
          <div class="spinner-border spinner-border-sm text-primary" role="status">
            <span class="sr-only small">&nbsp;</span>
          </div>
		</div>
		<h6 align="center">Days</h6>
        <div id="hours" class="rounded-lg mb-2" style="height: 40px; display: flex; align-content: center; justify-content: center; align-items: center; font-size: 18px; background-color: white">
          <div class="spinner-border spinner-border-sm text-primary" role="status">
            <span class="sr-only small">&nbsp;</span>
          </div>
		</div>
		<h6 align="center">Hours</h6>
        <div id="minutes" class="rounded-lg mb-2" style="height: 40px; display: flex; align-content: center; justify-content: center; align-items: center; font-size: 18px; background-color: white">
          <div class="spinner-border spinner-border-sm text-primary" role="status">
            <span class="sr-only small">&nbsp;</span>
          </div>
		</div>
		<h6 align="center">Minutes</h6>
        <div id="seconds" class="rounded-lg mb-2" style="height: 40px; display: flex; align-content: center; justify-content: center; align-items: center; font-size: 18px; background-color: white">
          <div class="spinner-border spinner-border-sm text-primary" role="status">
            <span class="sr-only small">&nbsp;</span>
          </div>
		</div>
		<h6 align="center">Seconds</h6>
      </div>
    </div>
  </div>
</div>    </div>
  </div>
	<div class="modal fade" id="Conduct" tabindex="-1" aria-labelledby="ConductLabel" aria-hidden="true">
<div class="modal-dialog modal-dialog-centered">
<div class="modal-content">
<div class="modal-header d-block">
<h1 align="center" class="modal-title fs-4 mt-3 fw-bold" id="ConductLabel">Code of Conduct</h1>
</div>
<div class="modal-body p-4">
<p class="mb-0">We are dedicated to providing a harassment-free experience for everyone, regardless of gender, gender identity and expression, age, sexual orientation, disability, physical appearance, body size, race, ethnicity, religion (or lack thereof), or technology choices. We do not tolerate harassment of participants in any form. Suggestive statements, sexual innuendo, or offensive remarks are not appropriate during any activity, including during talks, poster sessions, workshops, social functions, after hours parties, via Zoom chat or on Twitter or other online media. Participants asked to stop any harassing behavior are expected to comply immediately. Those violating these rules may be sanctioned or expelled without a refund at the discretion of the organizers. If you are being harassed, notice that someone else is being harassed, or have any other concerns about participant behavior, please notify the organizers immediately.</p>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-primary w-100 text-center" data-bs-dismiss="modal">Close</button>
</div>
</div>
</div>
</div>

<div class="modal fade" id="Hotel" tabindex="-1" aria-labelledby="HotelLabel" aria-hidden="true">
<div class="modal-dialog modal-dialog-centered" style="max-width: 535px !important">
<div class="modal-content">
<div class="modal-header d-block">
<p align="center" class="mt-2"><i class="fa-solid fa-triangle-exclamation" style="font-size:50px; color:#970001"></i></p>
<h1 class="modal-title fs-4 mt-3" id="HotelLabel">Hotel Reservation Fraud Alert</h1>
</div>
<div class="modal-body p-4">
<p class="mb-0">It is possible you may be contacted by a company claiming to be the official housing bureau for this conference. These companies contact conference exhibitors and attendees, telling them the guest room block is sold out at the host hotel. The company then quotes a rate at another hotel, claiming it is an official room block and that you must reserve through them to get discounted rates. They ask for your credit card information so they can make a reservation for you. <strong>DO NOT FALL FOR THIS</strong> or you will lose your money. This scam is affecting conferences all over the country. No matter what meeting you attend, always use the hotel reservation links provided on the host organization’s website.</p>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-primary w-100 text-center" data-bs-dismiss="modal">Close</button>
</div>
</div>
</div>
</div>	<div class="d-print-none text-center py-3 bg-white">
  <button type="button" value="Start Slideshow" class="play border-0" style="background: none; color: #767676"><i class="fas fa-play" aria-hidden="true" aria-label="Start Slideshow"></i></button> &nbsp;/&nbsp; <button type="button" value="Pause Slideshow" class="stop border-0" style="background: none; color: #767676"><i class="fas fa-pause" aria-hidden="true" aria-label="Pause Slideshow"></i></button>
</div>
<div class="d-print-none container-fluid p-0" style="cursor: grab">
  <div class="owl-carousel">
	<img src="images/carousel/home-image4.jpg" alt="Carousel Image">
    <img src="images/carousel/home-image5.jpg" alt="Carousel Image">
    <img src="images/carousel/home-image6.jpg" alt="Carousel Image">
	<img src="images/carousel/home-image3.jpg" alt="Carousel Image">
    <img src="images/carousel/home-image7.jpg" alt="Carousel Image">
	<img src="images/carousel/home-image9.jpg" alt="Carousel Image">
    <!--<img src="images/carousel/home-image2.jpg" alt="Carousel Image">-->
	<img src="images/carousel/home-image1.jpg" alt="Carousel Image">
	<img src="images/carousel/home-image8.jpg" alt="Carousel Image">
	<img src="images/carousel/home-image10.jpg" alt="Carousel Image">
  </div>
</div>
<footer class="d-print-none mt-0 footer container-fluid pt-4 pb-5">
  <div class="container row d-flex justify-content-center align-content-center align-items-center pb-3" style="max-width: 900px;">
	<div class="col-lg-2 pt-3 my-4 text-center">
      <a href="https://carlos-alberto-silva.github.io/silvalab/lab.html" target="_blank"><img src="images/silvalab-hex-clip-trans-green.png" class="w-100 px-1" alt="SilvaLab" style="max-width: 150px;"></a>
    </div>
    <div class="col-lg-5 pt-3 my-4 text-center">
      <a href="https://ffgs.ifas.ufl.edu/" target="_blank"><img src="images/ufifas-sffgs-white.png" class="w-100" alt="UF/IFAS School of Forest, Fisheries, &amp; Geomatics Sciences Logo" style="max-width: 300px;"></a>
    </div>
	<div class="col-lg-5 pt-2 my-4 text-center">
      <a href="https://www.forestsat.com/" target="_blank"><img src="images/forest-sat-association-white.png" class="w-100" alt="UF/IFAS School of Forest, Fisheries, &amp; Geomatics Sciences Logo" style="max-width: 290px;"></a>
    </div>
  </div>
  <p class="text-center text-white">
    <small>Copyright © <script type="text/javascript">document.write(new Date().getFullYear());</script> All Rights Reserved<br>UF/IFAS Office of Conferences &amp; Institutes<br>
    <a href="#" data-bs-toggle="modal" data-bs-target="#Conduct">Code of Conduct</a> | <a href="https://privacy.ufl.edu/privacy-policies-and-procedures/onlineinternet-privacy-statement/" target="_blank">UF Privacy</a> | <button id="convertcolors" class="text-white border-0 bg-transparent px-0 fw-bold">Convert to Black</button><br><strong>Analytics:</strong> <a href="https://policies.google.com/privacy" target="_blank">Google Privacy Policy <i class="fa fa-external-link-alt" aria-hidden="true"></i></a></small>
  </p>
  <div class="row mx-auto mt-4" style="max-width: 200px">
    <div class="col text-center"><a href="https://x.com/ForestSAT/" target="_blank"><i class="bi bi-twitter-x text-white"></i></a></div>
    <div class="col text-center"><a href="https://www.facebook.com/ForestSAT/" target="_blank"><i class="bi bi-facebook text-white"></i></a></div>
    <div class="col text-center"><a href="https://www.youtube.com/@forestsat" target="_blank"><i class="bi bi-youtube text-white"></i></a></div>
    <div class="col text-center"><a href="https://www.instagram.com/explore/tags/forestsat/" target="_blank"><i class="bi bi-instagram text-white"></i></a></div>
    <div class="col text-center"><a href="https://www.linkedin.com/uas/login?session_redirect=https%3A%2F%2Fwww.linkedin.com%2Fgroups%2F13822028%2F" target="_blank"><i class="bi bi-linkedin text-white"></i></a></div>
  </div>
</footer>  <!-- Core JS CDN -->
<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<!-- Core Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>

<!-- Countdown Timer -->
<script>
// Set the date we're counting down to
var countDownDate = new Date("May 4, 2026  00:00:00").getTime();

// Update the count down every 1 second
var x = setInterval(function() {

// Get todays date and time
var now = new Date().getTime();

// Find the distance between now and the count down date
var distance = countDownDate - now;

// Time calculations for days, hours, minutes and seconds
var days = Math.floor(distance / (1000 * 60 * 60 * 24));
var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
var seconds = Math.floor((distance % (1000 * 60)) / 1000);

// Output the result in an element with id="days"
document.getElementById("days").innerHTML = days;
	
// Output the result in an element with id="hours"
document.getElementById("hours").innerHTML = hours;
	
// Output the result in an element with id="minutes"
document.getElementById("minutes").innerHTML = minutes;
	
// Output the result in an element with id="seconds"
document.getElementById("seconds").innerHTML = seconds;

// If the count down is over, write some text 
if (distance < 0) {
clearInterval(x);
document.getElementById("timer").innerHTML = "Conference has Ended";
}
}, 1000);
</script>

<!-- BG Video Play/Pause Buttons -->
<script> 
let vid = document.getElementById("bgvideo"); 
function playVid() { 
  vid.play(); 
} 
function pauseVid() { 
  vid.pause(); 
} 
</script>
<!-- Owl Carousel -->
<script src="js/owl.carousel.js" type="text/javascript"></script>
<script>
  $(document).ready(function() {
    $(".owl-carousel").owlCarousel();
  });
  var owl = $('.owl-carousel');
  owl.owlCarousel( {
    items:4,
    loop:true,
    margin:0,
    autoplay:true,
    autoplayTimeout:4000,
    autoplayHoverPause:true,
    responsive:{
      0:{
        items:2
      },
      600:{
        items:4
      }
    }
  });
  $('.play').on('click',function(){
    owl.trigger('play.owl.autoplay',[4000])
  })
  $('.stop').on('click',function(){
    owl.trigger('stop.owl.autoplay')
  });
</script>
<!-- Convert Heading Colors -->
<script>
  let button = document.getElementById('convertcolors');
  let containers = document.getElementsByClassName('heading');
  let bgContainers = document.getElementsByClassName('bg');
  function changeButtonText() {
    if (button.innerHTML === "Convert to Black")
      button.innerHTML = "Convert to Color";
    else
      button.innerHTML = "Convert to Black";
  }
  button.addEventListener('click', function() {
    for (let index = 0; index < containers.length; ++index)
      containers[index].classList.toggle('blacktext');
    for (let index = 0; index < bgContainers.length; ++index)
      bgContainers[index].classList.toggle('blackbg');
    changeButtonText();
  });
</script>  </body>
</html>